
package pruebatorneo;
import java.util.Arrays;
public class PruebaTorneo {
    //Clase Prueba/Ejecutor.
    public static void main(String[] args) {
        //Creacion de dos objetos de tipo Participante.
        Participante participante1 = new Participante("Julio Cesar", 53.3, 56.2);
        Participante participante2 = new Participante("Mario Rodrigez", 45.9, 50.6);
        //Inicializacion del arreglo con datos de tipo objeto Participante.
        Participante participantes[] = {participante1, participante2};
        
        /***
         * Tambien podemos inicializar el arreglo y declarar los objetos, inicializandolos directamente por medio del new.
         * De la siguiente forma: 
         * Participante participantes[] = {new Participante("Julio Cesar", 53.3, 56.2), new Participante("Mario Rodrigez", 45.9, 50.6)};
        */
        //Creacion del objeto de tipo Torneo.
        Torneo torneo = new Torneo("Estilo Libre", participantes);
        //Ciclo repetitivo for: nos permite recorrer nuestro arreglo llamando al metodo calcular para cada objeto participante. 
        for (Participante participante : torneo.participantes) {
            participante.calcularPromedioTiempo();
        }
        System.out.println(torneo);
    }
}
class Torneo {
    //Declaracion de atributos o datos de la clase. 
    public String categoriaNado;
    public Participante participantes[];
    //Constructor
    public Torneo(String categoriaNado, Participante[] participantes) {
        this.categoriaNado = categoriaNado;
        this.participantes = participantes;
    }
    //Metodo toString de la clase Torneo. 
    @Override
    public String toString() {
        return "Torneo{" + "Categoria de Nado: " + categoriaNado + "\n" 
                + "Participantes: " + Arrays.toString(participantes) + '}';
    }
}
class Participante {
    //Declaracion de datos o atributos de la clase.
    public String nomParticipante;
    public double tiempoClasificacion;
    public double tiempoFinal;
    public double promedioTiempo;
    //Constructor
    public Participante(String nomParticipante, double tiempoClasificacion, double tiempoFinal) {
        this.nomParticipante = nomParticipante;
        this.tiempoClasificacion = tiempoClasificacion;
        this.tiempoFinal = tiempoFinal;
    }
    //Metodo toString de la clase Participante. 
    @Override
    public String toString() {
        return """
               Participante{
               Nombre del Participante: """ + nomParticipante + 
                "Tiempo de Clasificacion: " + tiempoClasificacion +
                "Tiempo Final: " + tiempoFinal +
                "Promedio de Tiempo: " + promedioTiempo + "\n" +'}';
    }
    //Metodo para calcular el promedio de tiempo por participante, para esto se suman los dos tiempos dados y se dividen para 2.
    public void calcularPromedioTiempo(){
        this.promedioTiempo = (this.tiempoClasificacion + this.tiempoFinal)/2;
    }
}

